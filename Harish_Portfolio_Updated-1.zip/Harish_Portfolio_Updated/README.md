# Harish K - Portfolio

A responsive personal portfolio website built with HTML, CSS and JavaScript.

## Files
- `index.html` - main portfolio page
- `style.css` - responsive styling
- `script.js` - mobile navigation interaction
- `assets/profile.png` - profile photo
- `assets/paper-presentation-certificate.jpg` - certificate

## Run locally
Open `index.html` in a browser, or use VS Code Live Server.

## Personal details used
The content is based on the supplied resume and certificate. Replace any contact/social details if they change.
